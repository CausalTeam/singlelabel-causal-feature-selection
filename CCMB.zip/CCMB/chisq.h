#pragma once

double gammq(double a, double x);